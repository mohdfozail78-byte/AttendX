# AttendX Flutter MVP

Production-style UI starter for the AttendX HRMS attendance app.

## Included
- Employee, Manager and Admin role flows
- Splash and login
- Employee dashboard
- Punch verification bottom sheet
- Location verification UI
- Selfie/face verification UI
- Attendance success
- Attendance logs + detail
- Leave apply/history
- Regularization
- Requests and notifications
- Profile
- Manager dashboard, team attendance, approvals, employee details, reports
- Admin dashboard, employee management, add employee, location management, add location, reports, settings
- Reusable cards, badges, bottom navigation, dialogs and empty states
- Local mock state for attendance/requests

## Run
```bash
flutter pub get
flutter run
```

## Important
The project is intentionally backend-free so it can run immediately. Real GPS, camera and face matching require platform permissions and a backend/face-recognition service. `geolocator` and `image_picker` are included and the service layer is structured so real APIs can be added.

For Google Maps, add an API key in Android/iOS platform configuration before using the map widget. The current UI uses a map-style placeholder to keep the app runnable without keys.
