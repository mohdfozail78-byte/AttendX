# AttendX Flutter MVP

AttendX is a Flutter MVP for a smart HRMS attendance application.

## Build APK on GitHub (from an Android phone)

1. Create a new GitHub repository.
2. Upload all files from this project to the repository root.
3. Open **Actions** in GitHub.
4. Select **Build AttendX APK**.
5. Tap **Run workflow**.
6. After the build finishes, open the workflow run.
7. Download the **attendx-release-apk** artifact.
8. Extract it and install `app-release.apk` on your Android phone.

## Local build

```bash
flutter pub get
flutter build apk --release
```

## Important

This is an MVP/frontend project. Production deployment still requires a real backend/database, secure authentication, server-side attendance validation, production geofencing, and a production-grade face-verification implementation.
